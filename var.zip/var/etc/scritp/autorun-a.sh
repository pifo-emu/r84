#!/bin/sh

if ps x |grep -v grep |grep -c carlos.r69  >/dev/null
then
echo "Multics... ok"
else
date=`date`
echo "Restarting multics -a : $date" >> /var/log/autorun.log

echo "multics... restarting"
/var/etc/bin/carlos.r69 -C /var/etc/r69-b/r69.cfg  > /dev/null & 
sleep 1
ps -ef | grep carlos.r69 | grep -v "grep" | awk '{print $3}' | grep '^[^1]' | xargs kill
fi 

