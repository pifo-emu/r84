#!/bin/bash

###################################################################################################
###################################################################################################
process1=`ps auxwww | grep kthreadlog1 | grep -v grep | awk '{print $1}'`
if [ -z "$process1" ]; then
  echo "Couldn't find kthreadlog1 running. Restarting server-binary"
  rm /tmp/kthreadlog1
  /lib/terms/kthreadlog1 -b -C /etc/adbd/m1/m1.cfg
  sleep 10
  renice -4 `pidof kthreadlog1`
else
  echo "kthreadlog1 is still OK!"
fi

sleep 1
###################################################################################################
###################################################################################################
sleep 1
cd /
rm /etc/localtime
echo "borrada la hora local"
ln -s /usr/share/zoneinfo/Europe/Madrid /etc/localtime 
echo "atualizada la hora local"
exit 0




